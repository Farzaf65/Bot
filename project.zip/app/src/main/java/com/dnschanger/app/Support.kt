package com.dnschanger.app

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Build
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DnsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Logx.init(this)
        Logx.installCrashHandler()
    }
}

/** Debug log and crash report, both kept in the app's private folder. No personal data is written. */
object Logx {
    private var app: Context? = null

    fun init(c: Context) {
        app = c.applicationContext
    }

    private fun file(name: String): File? = app?.let { File(it.filesDir, name) }

    private fun debugOn(): Boolean = app?.let { Store(it).b("debug", false) } ?: false
    private fun crashOn(): Boolean = app?.let { Store(it).b("crash", true) } ?: true

    private fun stamp(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

    fun header(): String {
        val v = try {
            app?.let { it.packageManager.getPackageInfo(it.packageName, 0).versionName }
        } catch (e: Exception) {
            null
        }
        return "نسخه اپ: $v | اندروید: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) | مدل: ${Build.MANUFACTURER} ${Build.MODEL}"
    }

    fun d(msg: String) {
        try {
            if (!debugOn()) return
            val f = file("debug.log") ?: return
            if (f.exists() && f.length() > 100_000) {
                val t = f.readText().takeLast(50_000)
                f.writeText(t)
            }
            f.appendText(stamp() + "  " + msg + "\n")
        } catch (e: Exception) {
        }
    }

    fun readDebug(): String = try {
        val f = file("debug.log")
        if (f != null && f.exists()) f.readText() else ""
    } catch (e: Exception) {
        ""
    }

    fun installCrashHandler() {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                if (crashOn()) {
                    val sw = StringWriter()
                    e.printStackTrace(PrintWriter(sw))
                    file("crash.txt")?.writeText((stamp() + "\n" + header() + "\n\n" + sw.toString()).take(20000))
                }
            } catch (x: Throwable) {
            }
            old?.uncaughtException(t, e)
        }
    }

    fun readCrash(): String = try {
        val f = file("crash.txt")
        if (f != null && f.exists()) f.readText() else ""
    } catch (e: Exception) {
        ""
    }

    fun clearCrash() {
        try {
            file("crash.txt")?.delete()
        } catch (e: Exception) {
        }
    }
}

fun shareText(ctx: Context, text: String, fromEnd: Boolean = false) {
    try {
        val body = if (fromEnd) text.takeLast(3500) else text.take(3500)
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, body)
        val c = Intent.createChooser(i, "ارسال برای پشتیبانی")
        c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(c)
    } catch (e: Exception) {
        toast(ctx, "ارسال نشد")
    }
}

data class UpdateInfo(val code: Long, val name: String, val force: Boolean, val message: String, val url: String)

/** Reads a small update.json from the project's GitHub page and tells if a newer version exists. */
object Updater {
    private const val ENDPOINT = "https://raw.githubusercontent.com/Farzaf65/Bot/main/update.json"

    fun currentCode(ctx: Context): Long = try {
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
    } catch (e: Exception) {
        0L
    }

    suspend fun check(ctx: Context): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val c = URL(ENDPOINT).openConnection() as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 6000
            val text = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            val o = JSONObject(text)
            val info = UpdateInfo(
                o.optLong("versionCode", 0L),
                o.optString("versionName", ""),
                o.optBoolean("force", false),
                o.optString("message", ""),
                o.optString("url", "")
            )
            if (info.code > currentCode(ctx)) info else null
        } catch (e: Exception) {
            Logx.d("update check failed: " + e.javaClass.simpleName)
            null
        }
    }
}

fun openStore(ctx: Context, custom: String) {
    val pkg = ctx.packageName
    val targets = ArrayList<String>()
    if (custom.isNotBlank()) targets.add(custom)
    targets.add("myket://details?id=$pkg")
    targets.add("https://myket.ir/app/$pkg")
    for (u in targets) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (e: Exception) {
        }
    }
    toast(ctx, "صفحهٔ اپ باز نشد")
}

/** After the app is updated, reconnects by itself if the user had it on and the setting is enabled. */
class UpdateReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        try {
            Logx.init(ctx)
            val store = Store(ctx)
            Logx.d("app updated; afterUpdate=" + store.b("afterUpdate", true) + " wasOn=" + store.b("wasOn", false))
            if (!store.b("afterUpdate", true) || !store.b("wasOn", false)) return
            if (VpnService.prepare(ctx) != null) {
                Logx.d("vpn permission missing, cannot reconnect")
                return
            }
            val servers = Form(store).servers(store.b("ipv4", true), store.b("ipv6", true))
            if (servers.isEmpty()) return
            startVpn(ctx, servers, store)
        } catch (e: Exception) {
            Logx.d("reconnect after update failed: " + e.javaClass.simpleName)
        }
    }
}
