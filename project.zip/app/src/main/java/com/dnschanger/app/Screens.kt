package com.dnschanger.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

fun startVpn(ctx: Context, servers: ArrayList<String>, store: Store) {
    val i = Intent(ctx, DnsVpnService::class.java)
    i.action = DnsVpnService.ACTION_START
    i.putStringArrayListExtra(DnsVpnService.EXTRA_DNS, servers)
    i.putStringArrayListExtra(DnsVpnService.EXTRA_EXCL, ArrayList(store.excl))
    i.putExtra(DnsVpnService.EXTRA_BLACK, store.b("blacklist", true))
    i.putExtra(DnsVpnService.EXTRA_NOTIF, store.b("notif", true))
    i.putExtra(DnsVpnService.EXTRA_SHOWDNS, store.b("showDns", true))
    ctx.startService(i)
}

fun stopVpn(ctx: Context) {
    val i = Intent(ctx, DnsVpnService::class.java)
    i.action = DnsVpnService.ACTION_STOP
    ctx.startService(i)
}

@Composable
fun TopBar(connected: Boolean, connecting: Boolean, onMenu: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            IconButton(
                onClick = onMenu,
                modifier = Modifier.size(46.dp).border(1.dp, Line, CircleShape).background(Surface.copy(alpha = 0.8f), CircleShape)
            ) {
                Icon(Icons.Filled.Menu, contentDescription = "منو", tint = Fg)
            }
            Text("DNS چنجر", color = Fg, fontSize = 19.sp, fontWeight = FontWeight.Black)
        }
        val label = if (connected) "متصل" else if (connecting) "در حال اتصال" else "قطع"
        val dot = if (connected) Accent else if (connecting) Warn else Muted
        Row(
            Modifier
                .border(1.dp, if (connected) Accent.copy(alpha = 0.5f) else Line, CircleShape)
                .background(Surface.copy(alpha = 0.8f), CircleShape)
                .padding(horizontal = 14.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(Modifier.size(8.dp).background(dot, CircleShape))
            Text(label, color = if (connected) Fg else Muted, fontSize = 13.sp)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    form: Form,
    all: List<DnsItem>,
    connected: Boolean,
    onMenu: () -> Unit,
    onOpenList: () -> Unit,
    onAddService: (String) -> Unit
) {
    val ctx = LocalContext.current
    val store = form.store
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val scroll = rememberScrollState()
    var connecting by remember { mutableStateOf(false) }
    var step by remember { mutableIntStateOf(0) }
    var secs by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    val connNow by rememberUpdatedState(connected)
    val bring4 = remember { BringIntoViewRequester() }
    val bring6 = remember { BringIntoViewRequester() }
    val focus4 = remember { FocusRequester() }
    val focus6 = remember { FocusRequester() }

    val total = 3
    val match = all.firstOrNull { it.p == form.p4.trim() && it.s == form.s4.trim() }
    val dnsLabel = match?.name ?: if (form.p4.isNotBlank() && Check.ip4(form.p4)) form.p4.trim() else "DNS شما"
    val nodes: List<Pair<String, Int>> = listOf(dnsLabel to 1)
    val locked = connected || connecting

    fun dnsList(): ArrayList<String> = form.servers(store.b("ipv4", true), store.b("ipv6", true))

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            startVpn(ctx, dnsList(), store)
        } else {
            connecting = false
            toast(ctx, "مجوز VPN داده نشد. بدون مجوز اتصال برقرار نمی‌شه.")
        }
    }

    LaunchedEffect(connected) {
        if (connected) {
            connecting = false
            step = 1
            delay(500)
            step = 2
            delay(600)
            step = 3
        } else {
            step = 0
        }
    }
    LaunchedEffect(connected) {
        secs = 0
        while (connected) {
            delay(1000)
            secs++
        }
    }
    LaunchedEffect(connecting) {
        if (connecting) {
            delay(8000)
            if (connecting && !connNow) {
                connecting = false
                toast(ctx, DnsVpnService.lastError.value ?: "اتصال برقرار نشد. دوباره امتحان کن.")
            }
        }
    }

    fun onPower() {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        if (connected) {
            stopVpn(ctx)
            return
        }
        if (connecting) return
        val bad = form.validate()
        if (bad >= 0) {
            scope.launch {
                delay(200)
                when (bad) {
                    0 -> {
                        bring4.bringIntoView()
                        focus4.requestFocus()
                    }
                    2 -> {
                        bring6.bringIntoView()
                        focus6.requestFocus()
                    }
                    else -> scroll.animateScrollTo(scroll.maxValue)
                }
            }
            return
        }
        form.persist()
        if (dnsList().isEmpty()) {
            toast(ctx, "با تنظیمات فعلی (IPv4 یا IPv6 خاموشه) هیچ DNSی برای استفاده نمونده.")
            return
        }
        connecting = true
        val prep = VpnService.prepare(ctx)
        if (prep != null) launcher.launch(prep) else startVpn(ctx, dnsList(), store)
    }

    val subtitle = when {
        connected -> "DNS روی $dnsLabel تنظیم شده"
        connecting -> "مجوز VPN و برقراری اتصال"
        else -> "DNS رو وارد کن و دکمه رو لمس کن"
    }
    val pathMsg = when {
        step == 0 -> "با لمس دکمه، مسیر اتصال تا اینترنت نمایش داده می‌شه."
        step == 1 -> "اپلیکیشن DNS چنجر شروع شد."
        step >= total -> "به اینترنت رسیدی و سرویس فعاله."
        else -> "درخواست‌ها به $dnsLabel می‌رن."
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 4.dp)
    ) {
        TopBar(connected, connecting, onMenu)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            PowerButton(connected, connecting) { onPower() }
        }
        Spacer(Modifier.height(6.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                if (connected) "متصل شد" else if (connecting) "در حال اتصال..." else "قطع است",
                color = if (connected) Accent else Fg,
                fontSize = 26.sp,
                fontWeight = FontWeight.Black
            )
            Text(subtitle, color = Muted, fontSize = 13.5.sp, textAlign = TextAlign.Center)
            val h = secs / 3600
            val m = (secs % 3600) / 60
            val s = secs % 60
            Text(
                String.format("%02d:%02d:%02d", h, m, s),
                color = if (connected) Fg else Muted,
                fontFamily = FontFamily.Monospace,
                fontSize = 15.sp
            )
        }
        Spacer(Modifier.height(14.dp))
        PathRow(step, nodes, connected)
        Text(
            pathMsg,
            color = if (step >= total) Good else Muted,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 18.dp)
        )

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("DNS دلخواه", color = Fg, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            TextButton(onClick = onOpenList) { Text("انتخاب از لیست", color = Accent, fontWeight = FontWeight.Bold) }
        }
        Text(
            "آدرس DNS خودت یا هر شرکتی رو تایپ کن. فقط DNS اصلی با IPv4 (نسل ۴) اجباریه.",
            color = Muted,
            fontSize = 13.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        DnsField(
            "DNS اصلی", "IPv4 · اجباری", form.p4,
            { form.p4 = it; form.e4 = null; form.persist() },
            "8.8.8.8", form.e4, null, !locked,
            Modifier.bringIntoViewRequester(bring4).focusRequester(focus4)
        )
        Spacer(Modifier.height(10.dp))
        DnsField(
            "DNS دوم", "IPv4 · اختیاری", form.s4,
            { form.s4 = it; form.es4 = null; form.persist() },
            "8.8.4.4", form.es4, null, !locked
        )
        Spacer(Modifier.height(10.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .border(1.5.dp, Line, RoundedCornerShape(36.dp))
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(Modifier.weight(1f)) {
                Text("IPv6 (نسل ۶)", color = Fg, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                Text("اختیاری. اگه روشنش کنی، DNS اصلی IPv6 اجباری می‌شه.", color = Muted, fontSize = 12.5.sp)
            }
            Sw(form.v6) {
                if (!locked) {
                    form.v6 = it
                    if (!it) {
                        form.e6 = null
                        form.es6 = null
                    }
                    form.persist()
                }
            }
        }
        AnimatedVisibility(form.v6) {
            Column(Modifier.padding(top = 10.dp)) {
                val warn6 = if (form.p6.isBlank() && form.e6 == null) "کادر اول نسل ۶ نباید خالی باشه." else null
                DnsField(
                    "DNS اصلی", "IPv6 · اجباری", form.p6,
                    { form.p6 = it; form.e6 = null; form.persist() },
                    "2001:4860:4860::8888", form.e6, warn6, !locked,
                    Modifier.bringIntoViewRequester(bring6).focusRequester(focus6)
                )
                Spacer(Modifier.height(10.dp))
                DnsField(
                    "DNS دوم", "IPv6 · اختیاری", form.s6,
                    { form.s6 = it; form.es6 = null; form.persist() },
                    "2001:4860:4860::8844", form.es6, null, !locked
                )
            }
        }

        Row(Modifier.padding(top = 16.dp, bottom = 28.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                Modifier
                    .clip(CircleShape)
                    .border(1.dp, Accent.copy(alpha = 0.5f), CircleShape)
                    .background(Accent.copy(alpha = 0.06f))
                    .clickable {
                        if (locked) {
                            toast(ctx, "اول اتصال رو قطع کن")
                        } else {
                            val bad = form.validate()
                            if (bad >= 0) {
                                toast(ctx, "اول DNS اصلی رو درست وارد کن")
                            } else {
                                showAdd = true
                            }
                        }
                    }
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, tint = Accent, modifier = Modifier.size(18.dp))
                Text("افزودن سرویس DNS", color = Accent, fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = {
                if (locked) toast(ctx, "اول اتصال رو قطع کن") else form.clear()
            }) { Text("پاک کردن", color = Accent, fontWeight = FontWeight.Bold) }
        }
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            containerColor = Surface2,
            title = { Text("افزودن سرویس DNS", color = Fg) },
            text = {
                Column {
                    val v6on = form.v6 && (form.p6.isNotBlank() || form.s6.isNotBlank())
                    Text(
                        if (v6on) "این سرویس با IPv4 و IPv6 ذخیره می‌شه." else "این سرویس فقط با IPv4 ذخیره می‌شه.",
                        color = Muted, fontSize = 14.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = name,
                        onValueChange = { if (it.length <= 24) name = it },
                        singleLine = true,
                        placeholder = { Text("مثلاً DNS خودم", color = Muted) },
                        shape = RoundedCornerShape(30.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Accent, unfocusedBorderColor = Line,
                            focusedTextColor = Fg, unfocusedTextColor = Fg, cursorColor = Accent
                        )
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isBlank()) {
                        toast(ctx, "یه اسم برای سرویس بنویس.")
                    } else {
                        onAddService(name.trim())
                        showAdd = false
                        toast(ctx, "به لیست اضافه شد")
                    }
                }) { Text("افزودن", color = Accent, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("لغو", color = Muted) } }
        )
    }
}

@Composable
fun ListScreen(
    all: List<DnsItem>,
    favs: Set<String>,
    form: Form,
    connected: Boolean,
    onMenu: () -> Unit,
    onFav: (String) -> Unit,
    onDelete: (String) -> Unit,
    onPick: (DnsItem) -> Unit
) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("all") }
    val cats = listOf("all" to "همه", "fav" to "علاقه‌مندی", "سرعت" to "سرعت", "امنیت" to "امنیت", "بلاک تبلیغ" to "بلاک تبلیغ", "گیمینگ" to "گیمینگ", "دلخواه" to "دلخواه")
    val shown = all.filter { d ->
        val okCat = when (cat) {
            "all" -> true
            "fav" -> d.id in favs
            else -> cat in d.tags
        }
        val okQ = q.isBlank() || d.name.contains(q.trim(), ignoreCase = true) || d.p.contains(q.trim()) || d.s.contains(q.trim())
        okCat && okQ
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                TopBar(connected, false, onMenu)
                Spacer(Modifier.height(10.dp))
                Text("لیست DNS", color = Fg, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text(
                    "هر کدوم رو انتخاب کنی، تو فیلدهای خانه وارد می‌شه. استفاده از لیست اجباری نیست.",
                    color = Muted, fontSize = 13.5.sp, modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                )
                OutlinedTextField(
                    value = q,
                    onValueChange = { q = it },
                    singleLine = true,
                    placeholder = { Text("جستجو: اسم یا آدرس", color = Muted) },
                    shape = RoundedCornerShape(36.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Accent, unfocusedBorderColor = Line,
                        focusedTextColor = Fg, unfocusedTextColor = Fg, cursorColor = Accent,
                        focusedContainerColor = Surface.copy(alpha = 0.7f), unfocusedContainerColor = Surface.copy(alpha = 0.7f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(cats) { c ->
                        val on = cat == c.first
                        Box(
                            Modifier
                                .clip(CircleShape)
                                .background(if (on) Accent else Surface)
                                .border(1.dp, if (on) Accent else Line, CircleShape)
                                .clickable { cat = c.first }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(c.second, color = if (on) AccentInk else Muted, fontSize = 13.5.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }
            }
        }
        if (shown.isEmpty()) {
            item {
                Box(
                    Modifier.fillMaxWidth().border(1.dp, Line, RoundedCornerShape(30.dp)).padding(28.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (cat == "fav") "هنوز DNSی رو با قلب علامت نزدی." else "موردی پیدا نشد.", color = Muted)
                }
            }
        }
        items(shown, key = { it.id }) { d ->
            val sel = form.p4.trim() == d.p && form.s4.trim() == d.s
            val fav = d.id in favs
            val has6 = d.p6.isNotEmpty() || d.s6.isNotEmpty()
            Row(
                Modifier
                    .fillMaxWidth()
                    .animateContentSize()
                    .background(Brush.verticalGradient(listOf(Surface2.copy(alpha = 0.7f), Surface.copy(alpha = 0.85f))), RoundedCornerShape(34.dp))
                    .border(if (sel) 1.5.dp else 1.dp, if (sel) Accent.copy(alpha = 0.65f) else Line, RoundedCornerShape(34.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    Modifier.size(48.dp).background(Brush.linearGradient(listOf(Color(d.c1), Color(d.c2))), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    val letter = d.name.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "D"
                    Text(letter, color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp)
                }
                Column(Modifier.weight(1f)) {
                    Text(d.name, color = Fg, fontWeight = FontWeight.ExtraBold)
                    val mono = TextStyle(color = Muted, fontFamily = FontFamily.Monospace, fontSize = 12.5.sp, textDirection = TextDirection.Ltr, textAlign = TextAlign.Left)
                    Text(d.p, style = mono, modifier = Modifier.fillMaxWidth())
                    if (d.s.isNotEmpty()) Text(d.s, style = mono, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        d.tags.take(2).forEach { t ->
                            Box(Modifier.border(1.dp, Line, CircleShape).padding(horizontal = 8.dp)) { Text(t, color = Muted, fontSize = 11.5.sp) }
                        }
                        Box(Modifier.border(1.dp, if (has6) Violet.copy(alpha = 0.5f) else Line, CircleShape).padding(horizontal = 8.dp)) {
                            Text(if (has6) "IPv4 + IPv6" else "فقط IPv4", color = if (has6) Violet else Muted, fontSize = 11.5.sp)
                        }
                    }
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = { onFav(d.id) }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Filled.Favorite, contentDescription = "علاقه‌مندی", tint = if (fav) Warn else Muted.copy(alpha = 0.5f), modifier = Modifier.size(20.dp))
                    }
                    Box(
                        Modifier
                            .clip(CircleShape)
                            .background(if (sel) Accent else Surface2)
                            .border(1.dp, if (sel) Accent else Line, CircleShape)
                            .clickable {
                                if (connected) toast(ctx, "برای تغییر DNS اول اتصال رو قطع کن") else onPick(d)
                            }
                            .padding(horizontal = 16.dp, vertical = 7.dp)
                    ) {
                        Text(if (sel) "انتخاب‌شده" else "انتخاب", color = if (sel) AccentInk else Fg, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                    }
                    if (d.custom) {
                        IconButton(onClick = { onDelete(d.id) }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = Bad, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun AboutScreen(connected: Boolean, onMenu: () -> Unit) {
    val warnings = listOf(
        "این اپ فقط DNS رو عوض می‌کنه. فیلترشکن نیست و IP تو رو مخفی نمی‌کنه.",
        "سرعت و پینگ بعد از تغییر DNS تضمین نمی‌شه و به شبکه و اپراتور بستگی داره.",
        "اپ برای اعمال DNS از سرویس VPN اندروید استفاده می‌کنه. ترافیک تو ذخیره یا ارسال نمی‌شه.",
        "با DNS ناشناس احتیاط کن. سرور DNS می‌تونه ببینه کدوم سایت‌ها رو باز می‌کنی."
    )
    val faq = listOf(
        "چرا اندروید کلید VPN نشون می‌ده؟" to "اپ‌های تغییر DNS بدون روت از همین سرویس استفاده می‌کنن. فقط درخواست‌های DNS تغییر می‌کنن و بقیه ترافیک مستقیم می‌ره.",
        "اتصال برقرار نمی‌شه، چه کنم؟" to "آدرس DNS رو دوباره چک کن، یه DNS دیگه امتحان کن و مجوز VPN رو دوباره تأیید کن. اگه نشد، اینترنت گوشی رو یک بار قطع و وصل کن.",
        "کدوم DNS برای بازی بهتره؟" to "بستگی به اپراتور داره. چند DNS رو روی همون اینترنتی که بازی می‌کنی امتحان کن و علاقه‌مندی‌هات رو علامت بزن.",
        "IPv6 رو باید روشن کنم؟" to "لازم نیست. IPv4 برای کار اپ کافیه و IPv6 فقط وقتی مفیده که شبکه‌ات پشتیبانی کنه."
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        TopBar(connected, false, onMenu)
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .background(Surface2.copy(alpha = 0.7f), RoundedCornerShape(30.dp))
                .border(1.dp, Line, RoundedCornerShape(30.dp))
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(Modifier.size(52.dp).background(Brush.linearGradient(listOf(Accent, Violet)), CircleShape), contentAlignment = Alignment.Center) {
                Text("D", color = Color.White, fontWeight = FontWeight.Black, fontSize = 22.sp)
            }
            Column {
                Text("DNS چنجر", color = Fg, fontSize = 18.sp, fontWeight = FontWeight.Black)
                Text("نسخه 0.2", color = Muted, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Column(
            Modifier
                .fillMaxWidth()
                .background(Surface2.copy(alpha = 0.7f), RoundedCornerShape(30.dp))
                .border(1.dp, Line, RoundedCornerShape(30.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("ارتباط با ما", color = Fg, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            ContactRow("پشتیبانی تلگرام", "@PINGAMIRREZA", "https://t.me/PINGAMIRREZA")
            ContactRow("ایمیل", "farzad.km15@gmail.com", "mailto:farzad.km15@gmail.com")
            ContactRow("کانال تلگرام", "@last_circle_king", "https://t.me/last_circle_king")
            ContactRow("اینستاگرام", "last_circle_king", "https://instagram.com/last_circle_king")
            Text("هر ایرادی داشتین یه اسکرین‌شات برای من بفرستید.", color = Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.height(18.dp))
        Text("هشدارها", color = Fg, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(10.dp))
        warnings.forEach { w ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .background(Surface, RoundedCornerShape(28.dp))
                    .border(1.dp, Line, RoundedCornerShape(28.dp))
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(Modifier.size(10.dp).background(Warn, CircleShape))
                Text(w, color = Fg, fontSize = 14.sp, modifier = Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("سؤالات متداول", color = Fg, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(10.dp))
        faq.forEach { (q, a) ->
            var open by remember { mutableStateOf(false) }
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Surface)
                    .border(1.dp, Line, RoundedCornerShape(26.dp))
                    .clickable { open = !open }
                    .animateContentSize()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Text(q, color = Fg, fontWeight = FontWeight.Medium)
                if (open) {
                    Spacer(Modifier.height(8.dp))
                    Text(a, color = Muted, fontSize = 14.sp)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
