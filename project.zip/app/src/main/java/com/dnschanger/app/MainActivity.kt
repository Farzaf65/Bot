package com.dnschanger.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { App() }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val form = remember { Form(store) }
    val scope = rememberCoroutineScope()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    var page by remember { mutableStateOf("home") }
    var favs by remember { mutableStateOf(store.favs) }
    var custom by remember { mutableStateOf(store.custom) }
    val wgStore = remember { WgStore(ctx) }
    val wgForm = remember { WgForm(wgStore) }
    val dnsUp by DnsVpnService.connected.collectAsState()
    val wgUp by Wg.up.collectAsState()
    val connected = dnsUp || wgUp
    val all = Builtin.all + custom

    BackHandler(enabled = page != "home") { page = if (page == "excl") "settings" else "home" }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    var unlocked by remember {
        mutableStateOf(!(store.b("pin", false) && store.pin.length == 4 && store.b("pinApp", true)))
    }

    fun go(p: String) {
        page = p
        scope.launch { drawer.close() }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = AccentInk,
            background = Bg,
            surface = Surface,
            onSurface = Fg,
            onBackground = Fg
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            if (!unlocked) {
                LockScreen(store) { unlocked = true }
            } else ModalNavigationDrawer(
                drawerState = drawer,
                drawerContent = { DrawerContent(page) { go(it) } }
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .drawBehind {
                            drawRect(Bg)
                            val r = size.width * 0.95f
                            drawCircle(
                                brush = Brush.radialGradient(
                                    listOf(Accent.copy(alpha = 0.18f), Color.Transparent),
                                    center = Offset(size.width / 2f, 0f),
                                    radius = r
                                ),
                                radius = r,
                                center = Offset(size.width / 2f, 0f)
                            )
                            val r2 = size.width * 0.7f
                            drawCircle(
                                brush = Brush.radialGradient(
                                    listOf(Violet.copy(alpha = 0.14f), Color.Transparent),
                                    center = Offset(size.width, size.height * 0.45f),
                                    radius = r2
                                ),
                                radius = r2,
                                center = Offset(size.width, size.height * 0.45f)
                            )
                        }
                        .systemBarsPadding()
                ) {
                    AnimatedContent(
                        targetState = page,
                        transitionSpec = {
                            (fadeIn(tween(380)) + slideInVertically(tween(380)) { it / 24 }) togetherWith fadeOut(tween(180))
                        },
                        label = "page"
                    ) { p ->
                        val openMenu: () -> Unit = { scope.launch { drawer.open() } }
                        when (p) {
                            "list" -> ListScreen(
                                all = all,
                                favs = favs,
                                form = form,
                                connected = connected,
                                onMenu = openMenu,
                                onFav = { id ->
                                    favs = if (id in favs) favs - id else favs + id
                                    store.favs = favs
                                },
                                onDelete = { id ->
                                    custom = custom.filter { it.id != id }
                                    store.custom = custom
                                    favs = favs - id
                                    store.favs = favs
                                },
                                onPick = { d ->
                                    form.fill(d)
                                    page = "home"
                                    toast(ctx, d.name + " تو فیلدها وارد شد")
                                }
                            )
                            "settings" -> SettingsScreen(store, connected, openMenu) { page = "excl" }
                            "excl" -> ExclScreen(store) { page = "settings" }
                            "about" -> AboutScreen(connected, openMenu)
                            else -> HomeScreen(
                                form = form,
                                wg = wgForm,
                                all = all,
                                connected = connected,
                                onMenu = openMenu,
                                onOpenList = { page = "list" },
                                onAddService = { name ->
                                    val v6 = form.v6
                                    val item = DnsItem(
                                        "c" + System.currentTimeMillis(), name,
                                        form.p4.trim(), form.s4.trim(),
                                        if (v6) form.p6.trim() else "",
                                        if (v6) form.s6.trim() else "",
                                        listOf("دلخواه"), 0xFF7C5CFF, 0xFF22D3EE, true
                                    )
                                    custom = custom + item
                                    store.custom = custom
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DrawerContent(page: String, onNav: (String) -> Unit) {
    val ctx = LocalContext.current
    ModalDrawerSheet(
        drawerContainerColor = Surface,
        drawerShape = RoundedCornerShape(topStart = 0.dp, topEnd = 36.dp, bottomEnd = 36.dp, bottomStart = 0.dp)
    ) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("DNS چنجر", color = Fg, fontSize = 20.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(start = 8.dp, top = 8.dp, bottom = 16.dp))
            val colors = NavigationDrawerItemDefaults.colors(
                selectedContainerColor = Accent.copy(alpha = 0.12f),
                unselectedContainerColor = Color.Transparent,
                selectedTextColor = Accent,
                unselectedTextColor = Fg,
                selectedIconColor = Accent,
                unselectedIconColor = Muted
            )
            NavigationDrawerItem(
                label = { Text("خانه") },
                selected = page == "home",
                onClick = { onNav("home") },
                icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                colors = colors,
                shape = CircleShape
            )
            NavigationDrawerItem(
                label = { Text("لیست DNS") },
                selected = page == "list",
                onClick = { onNav("list") },
                icon = { Icon(Icons.Filled.Search, contentDescription = null) },
                colors = colors,
                shape = CircleShape
            )
            NavigationDrawerItem(
                label = { Text("تنظیمات") },
                selected = page == "settings" || page == "excl",
                onClick = { onNav("settings") },
                icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                colors = colors,
                shape = CircleShape
            )
            NavigationDrawerItem(
                label = { Text("درباره ما") },
                selected = page == "about",
                onClick = { onNav("about") },
                icon = { Icon(Icons.Filled.Info, contentDescription = null) },
                colors = colors,
                shape = CircleShape
            )
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
            Spacer(Modifier.height(16.dp))
            Text("ارتباط با ما", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 8.dp, bottom = 8.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Surface2.copy(alpha = 0.7f), RoundedCornerShape(30.dp))
                    .border(1.dp, Line, RoundedCornerShape(30.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("پشتیبانی", color = Fg, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("سؤال یا مشکلی داشتی، تو تلگرام یا ایمیل پیام بده.", color = Muted, fontSize = 13.5.sp)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("@PINGAMIRREZA", color = Fg, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Pill("کپی") { copyText(ctx, "@PINGAMIRREZA") }
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(Accent, Color(0xFF5EEAD4))), CircleShape)
                        .clickable { openUrl(ctx, "https://t.me/PINGAMIRREZA") }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("پیام در تلگرام", color = AccentInk, fontWeight = FontWeight.Bold)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("farzad.km15@gmail.com", color = Fg, fontFamily = FontFamily.Monospace, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Pill("کپی") { copyText(ctx, "farzad.km15@gmail.com") }
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(Surface2, CircleShape)
                        .border(1.dp, Line, CircleShape)
                        .clickable { openUrl(ctx, "mailto:farzad.km15@gmail.com") }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("ارسال ایمیل", color = Fg, fontWeight = FontWeight.Bold)
                }
                Text(
                    "هر ایرادی داشتین یه اسکرین‌شات برای من بفرستید.",
                    color = Fg,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Warn.copy(alpha = 0.1f), RoundedCornerShape(22.dp))
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
            Spacer(Modifier.height(16.dp))
            Text("نسخه 0.2", color = Muted, fontSize = 12.5.sp, modifier = Modifier.fillMaxWidth().padding(8.dp))
        }
    }
}

@Composable
fun Pill(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .background(Surface2, CircleShape)
            .border(1.dp, Line, CircleShape)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(text, color = Fg, fontSize = 12.5.sp)
    }
}

fun copyText(ctx: Context, text: String) {
    try {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("text", text))
        toast(ctx, "کپی شد: $text")
    } catch (e: Exception) {
        toast(ctx, "کپی نشد")
    }
}

fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        toast(ctx, "برنامه‌ای برای باز کردن پیدا نشد")
    }
}
