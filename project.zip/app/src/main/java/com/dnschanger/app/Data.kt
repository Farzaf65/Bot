package com.dnschanger.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class DnsItem(
    val id: String,
    val name: String,
    val p: String,
    val s: String,
    val p6: String,
    val s6: String,
    val tags: List<String>,
    val c1: Long,
    val c2: Long,
    val custom: Boolean = false
)

object Builtin {
    val all: List<DnsItem> = listOf(
        DnsItem("cloudflare", "Cloudflare", "1.1.1.1", "1.0.0.1", "2606:4700:4700::1111", "2606:4700:4700::1001", listOf("سرعت", "گیمینگ"), 0xFFF6821F, 0xFFFBBF24),
        DnsItem("google", "Google", "8.8.8.8", "8.8.4.4", "2001:4860:4860::8888", "2001:4860:4860::8844", listOf("سرعت", "گیمینگ"), 0xFF4285F4, 0xFF22B8CF),
        DnsItem("quad9", "Quad9", "9.9.9.9", "149.112.112.112", "2620:fe::fe", "2620:fe::9", listOf("امنیت"), 0xFFE11D48, 0xFFFB7185),
        DnsItem("opendns", "OpenDNS", "208.67.222.222", "208.67.220.220", "2620:119:35::35", "2620:119:53::53", listOf("امنیت"), 0xFFEA580C, 0xFFF59E0B),
        DnsItem("adguard", "AdGuard", "94.140.14.14", "94.140.15.15", "2a10:50c0::ad1:ff", "2a10:50c0::ad2:ff", listOf("بلاک تبلیغ", "امنیت"), 0xFF16A34A, 0xFF4ADE80),
        DnsItem("cleanb", "CleanBrowsing", "185.228.168.9", "185.228.169.9", "2a0d:2a00:1::2", "2a0d:2a00:2::2", listOf("امنیت"), 0xFF0EA5E9, 0xFF6366F1)
    )
}

object Check {
    private val v4 = Regex("""^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$""")
    private val hexColon = Regex("^[0-9a-fA-F:]+$")

    fun ip4(value: String): Boolean {
        val m = v4.matchEntire(value.trim()) ?: return false
        return m.groupValues.drop(1).all { it.toInt() <= 255 }
    }

    fun ip6(value: String): Boolean {
        val s = value.trim()
        if (!hexColon.matches(s) || !s.contains(':')) return false
        val parts = s.split("::")
        if (parts.size > 2) return false
        fun seg(t: String): List<String> = if (t.isEmpty()) emptyList() else t.split(":")
        val g = seg(parts[0]) + (if (parts.size == 2) seg(parts[1]) else emptyList())
        if (!g.all { it.length in 1..4 }) return false
        return if (parts.size == 2) g.size <= 7 else g.size == 8
    }
}

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("dns", Context.MODE_PRIVATE)

    var p4: String
        get() = sp.getString("p4", "") ?: ""
        set(v) { sp.edit().putString("p4", v).apply() }
    var s4: String
        get() = sp.getString("s4", "") ?: ""
        set(v) { sp.edit().putString("s4", v).apply() }
    var p6: String
        get() = sp.getString("p6", "") ?: ""
        set(v) { sp.edit().putString("p6", v).apply() }
    var s6: String
        get() = sp.getString("s6", "") ?: ""
        set(v) { sp.edit().putString("s6", v).apply() }
    var v6: Boolean
        get() = sp.getBoolean("v6", false)
        set(v) { sp.edit().putBoolean("v6", v).apply() }

    var favs: Set<String>
        get() = (sp.getStringSet("favs", setOf("cloudflare", "google")) ?: emptySet()).toSet()
        set(v) { sp.edit().putStringSet("favs", HashSet(v)).apply() }

    var custom: List<DnsItem>
        get() {
            val out = ArrayList<DnsItem>()
            try {
                val arr = JSONArray(sp.getString("custom", "[]") ?: "[]")
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    out.add(
                        DnsItem(
                            o.getString("id"), o.getString("name"),
                            o.optString("p"), o.optString("s"),
                            o.optString("p6"), o.optString("s6"),
                            listOf("دلخواه"), 0xFF7C5CFF, 0xFF22D3EE, true
                        )
                    )
                }
            } catch (e: Exception) {
            }
            return out
        }
        set(v) {
            val arr = JSONArray()
            for (d in v) {
                val o = JSONObject()
                o.put("id", d.id)
                o.put("name", d.name)
                o.put("p", d.p)
                o.put("s", d.s)
                o.put("p6", d.p6)
                o.put("s6", d.s6)
                arr.put(o)
            }
            sp.edit().putString("custom", arr.toString()).apply()
        }
}

/** Holds the text fields of the home screen and their validation state. */
class Form(private val store: Store) {
    var p4 by mutableStateOf(store.p4)
    var s4 by mutableStateOf(store.s4)
    var p6 by mutableStateOf(store.p6)
    var s6 by mutableStateOf(store.s6)
    var v6 by mutableStateOf(store.v6)

    var e4 by mutableStateOf<String?>(null)
    var es4 by mutableStateOf<String?>(null)
    var e6 by mutableStateOf<String?>(null)
    var es6 by mutableStateOf<String?>(null)

    fun persist() {
        store.p4 = p4
        store.s4 = s4
        store.p6 = p6
        store.s6 = s6
        store.v6 = v6
    }

    fun clearErrors() {
        e4 = null
        es4 = null
        e6 = null
        es6 = null
    }

    fun fill(d: DnsItem) {
        p4 = d.p
        s4 = d.s
        p6 = d.p6
        s6 = d.s6
        v6 = d.p6.isNotEmpty() || d.s6.isNotEmpty()
        clearErrors()
        persist()
    }

    fun clear() {
        p4 = ""
        s4 = ""
        p6 = ""
        s6 = ""
        v6 = false
        clearErrors()
        persist()
    }

    /** Returns the index of the first bad field (0 p4, 1 s4, 2 p6, 3 s6) or -1 when all is fine. */
    fun validate(): Int {
        clearErrors()
        var first = -1
        if (p4.isBlank()) {
            e4 = "DNS اصلی IPv4 رو وارد کن. این کادر اجباریه."
            first = 0
        } else if (!Check.ip4(p4)) {
            e4 = "آدرس IPv4 معتبر نیست. مثلاً 8.8.8.8"
            first = 0
        }
        if (s4.isNotBlank() && !Check.ip4(s4)) {
            es4 = "آدرس معتبر نیست. این کادر رو می‌تونی خالی بذاری."
            if (first < 0) first = 1
        }
        if (v6) {
            if (p6.isBlank()) {
                e6 = "IPv6 روشنه، پس کادر اول نسل ۶ نباید خالی باشه. آدرس رو وارد کن یا IPv6 رو خاموش کن."
                if (first < 0) first = 2
            } else if (!Check.ip6(p6)) {
                e6 = "آدرس IPv6 معتبر نیست. مثلاً 2001:4860:4860::8888"
                if (first < 0) first = 2
            }
            if (s6.isNotBlank() && !Check.ip6(s6)) {
                es6 = "آدرس IPv6 معتبر نیست. این کادر رو می‌تونی خالی بذاری."
                if (first < 0) first = 3
            }
        }
        return first
    }

    fun servers(): ArrayList<String> {
        val l = ArrayList<String>()
        if (p4.isNotBlank()) l.add(p4.trim())
        if (s4.isNotBlank()) l.add(s4.trim())
        if (v6) {
            if (p6.isNotBlank()) l.add(p6.trim())
            if (s6.isNotBlank()) l.add(s6.trim())
        }
        return l
    }
}
