package com.dnschanger.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateMapOf
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.ByteArrayInputStream

val WG_KEYS = listOf("priv", "addr", "dns", "mtu", "pub", "psk", "ep", "allowed", "keep")

class WgField(
    val k: String,
    val name: String,
    val fa: String,
    val req: Boolean,
    val secret: Boolean,
    val peer: Boolean,
    val ph: String
)

val WGF = listOf(
    WgField("priv", "PrivateKey", "کلید خصوصی", true, true, false, "44 chars base64, ends with ="),
    WgField("addr", "Address", "آدرس تونل", true, false, false, "10.8.0.2/32"),
    WgField("dns", "DNS", "خالی باشه از DNS خانه استفاده می‌شه", false, false, false, "1.1.1.1"),
    WgField("mtu", "MTU", "پیش‌فرض 1420", false, false, false, "1420"),
    WgField("pub", "PublicKey", "کلید عمومی سرور", true, false, true, "44 chars base64, ends with ="),
    WgField("psk", "PresharedKey", "کلید پیش‌اشتراکی", false, true, true, "44 chars base64, ends with ="),
    WgField("ep", "Endpoint", "آدرس و پورت سرور", true, false, true, "vpn.example.com:51820"),
    WgField("allowed", "AllowedIPs", "مسیرهای عبوری از تونل", true, false, true, "0.0.0.0/0, ::/0"),
    WgField("keep", "PersistentKeepalive", "ثانیه", false, false, true, "25")
)

/** Keys are stored encrypted (Android Keystore). If that is not available they stay in memory only. */
class WgStore(ctx: Context) {
    private val mem = HashMap<String, String>()
    private val sp: SharedPreferences? = try {
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "wg_secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        null
    }

    fun get(k: String, def: String = ""): String {
        val s = sp
        return if (s != null) (s.getString(k, def) ?: def) else (mem[k] ?: def)
    }

    fun put(k: String, v: String) {
        val s = sp
        if (s != null) s.edit().putString(k, v).apply() else mem[k] = v
    }
}

object WgCheck {
    private val key = Regex("^[A-Za-z0-9+/]{43}=$")
    private val ep = Regex("^(\\[[0-9a-fA-F:]+\\]|[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?):(\\d{1,5})$")

    fun key(v: String): Boolean = key.matches(v)

    fun cidr(v: String): Boolean {
        val i = v.lastIndexOf('/')
        if (i <= 0) return false
        val a = v.substring(0, i)
        val n = v.substring(i + 1).toIntOrNull() ?: return false
        return if (Check.ip4(a)) n in 0..32 else if (Check.ip6(a)) n in 0..128 else false
    }

    fun list(v: String, f: (String) -> Boolean): Boolean {
        val l = v.split(",").map { it.trim() }
        return l.isNotEmpty() && l.all { it.isNotEmpty() && f(it) }
    }

    fun endpoint(v: String): Boolean {
        val m = ep.matchEntire(v) ?: return false
        val port = m.groupValues[2].toInt()
        if (port !in 1..65535) return false
        val h = m.groupValues[1]
        return if (h.startsWith("[")) Check.ip6(h.substring(1, h.length - 1)) else true
    }

    /** Returns pairs of (field key, message) for every problem. */
    fun check(w: Map<String, String>): List<Pair<String, String>> {
        val bad = ArrayList<Pair<String, String>>()
        fun chk(k: String, f: (String) -> Boolean, req: String?, msg: String) {
            val v = (w[k] ?: "").trim()
            if (v.isEmpty()) {
                if (req != null) bad.add(k to req)
            } else if (!f(v)) {
                bad.add(k to msg)
            }
        }
        chk("priv", { key(it) }, "کلید خصوصی اجباریه.", "کلید خصوصی باید ۴۴ کاراکتر base64 باشه و آخرش = داشته باشه.")
        chk("addr", { list(it) { x -> cidr(x) } }, "آدرس تونل اجباریه.", "آدرس معتبر نیست. مثلاً 10.8.0.2/32")
        chk("dns", { list(it) { x -> Check.ip4(x) || Check.ip6(x) } }, null, "DNS معتبر نیست. مثلاً 1.1.1.1")
        chk("mtu", { x -> x.toIntOrNull()?.let { n -> n in 1280..1500 } ?: false }, null, "MTU باید بین 1280 و 1500 باشه.")
        chk("pub", { key(it) }, "کلید عمومی سرور اجباریه.", "کلید عمومی باید ۴۴ کاراکتر base64 باشه و آخرش = داشته باشه.")
        chk("psk", { key(it) }, null, "کلید پیش‌اشتراکی باید ۴۴ کاراکتر base64 باشه و آخرش = داشته باشه.")
        chk("ep", { endpoint(it) }, "آدرس سرور اجباریه.", "آدرس معتبر نیست. مثلاً vpn.example.com:51820")
        chk("allowed", { list(it) { x -> cidr(x) } }, "AllowedIPs اجباریه.", "معتبر نیست. مثلاً 0.0.0.0/0, ::/0")
        chk("keep", { x -> x.toIntOrNull()?.let { n -> n in 0..65535 } ?: false }, null, "عدد بین 0 و 65535 بنویس.")
        return bad
    }

    fun parse(text: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        var sec = ""
        var peers = 0
        val map = mapOf(
            "privatekey" to "priv", "address" to "addr", "dns" to "dns", "mtu" to "mtu",
            "publickey" to "pub", "presharedkey" to "psk", "endpoint" to "ep",
            "allowedips" to "allowed", "persistentkeepalive" to "keep"
        )
        for (raw in text.split("\n")) {
            val line = raw.replace("\r", "").replace(Regex("[#;].*$"), "").trim()
            if (line.isEmpty()) continue
            if (line.startsWith("[") && line.endsWith("]")) {
                sec = line.substring(1, line.length - 1).trim().lowercase()
                if (sec == "peer") peers++
                continue
            }
            val i = line.indexOf('=')
            if (i < 0) continue
            val k = map[line.substring(0, i).trim().lowercase()] ?: continue
            if (sec == "peer" && peers > 1) continue
            out[k] = line.substring(i + 1).trim()
        }
        return out
    }

    fun hasAmnezia(text: String): Boolean {
        return Regex("(?im)^\\s*(Jc|Jmin|Jmax|S1|S2|H1|H2|H3|H4)\\s*=").containsMatchIn(text)
    }

    fun build(w: Map<String, String>, dnsOverride: List<String>?): String {
        val sb = StringBuilder()
        sb.append("[Interface]\n")
        sb.append("PrivateKey = ").append((w["priv"] ?: "").trim()).append("\n")
        sb.append("Address = ").append((w["addr"] ?: "").trim()).append("\n")
        val dns = if (dnsOverride != null && dnsOverride.isNotEmpty()) dnsOverride.joinToString(", ") else (w["dns"] ?: "").trim()
        if (dns.isNotEmpty()) sb.append("DNS = ").append(dns).append("\n")
        val mtu = (w["mtu"] ?: "").trim()
        if (mtu.isNotEmpty()) sb.append("MTU = ").append(mtu).append("\n")
        sb.append("\n[Peer]\n")
        sb.append("PublicKey = ").append((w["pub"] ?: "").trim()).append("\n")
        val psk = (w["psk"] ?: "").trim()
        if (psk.isNotEmpty()) sb.append("PresharedKey = ").append(psk).append("\n")
        sb.append("Endpoint = ").append((w["ep"] ?: "").trim()).append("\n")
        sb.append("AllowedIPs = ").append((w["allowed"] ?: "").trim()).append("\n")
        val keep = (w["keep"] ?: "").trim()
        if (keep.isNotEmpty()) sb.append("PersistentKeepalive = ").append(keep).append("\n")
        return sb.toString()
    }
}

/** Holds the WireGuard text fields and their errors. */
class WgForm(private val store: WgStore) {
    val v = mutableStateMapOf<String, String>()
    val err = mutableStateMapOf<String, String>()

    init {
        for (k in WG_KEYS) v[k] = store.get(k, if (k == "allowed") "0.0.0.0/0, ::/0" else "")
    }

    fun set(k: String, x: String) {
        v[k] = x
        store.put(k, x)
        err.remove(k)
    }

    fun setChecked(k: String, x: String) {
        set(k, x)
        val e = WgCheck.check(v.toMap()).firstOrNull { it.first == k }
        if (e != null) err[k] = e.second
    }

    fun ready(): Boolean {
        for (k in listOf("priv", "addr", "pub", "ep")) if ((v[k] ?: "").isBlank()) return false
        return true
    }

    fun resetAdvanced() {
        for (k in listOf("dns", "mtu", "keep")) set(k, "")
        set("allowed", "0.0.0.0/0, ::/0")
    }

    fun fill(m: Map<String, String>) {
        for ((k, x) in m) set(k, x)
    }

    fun clear() {
        for (k in WG_KEYS) set(k, if (k == "allowed") "0.0.0.0/0, ::/0" else "")
        err.clear()
    }

    fun check(): List<Pair<String, String>> {
        err.clear()
        val l = WgCheck.check(v.toMap())
        for (p in l) err[p.first] = p.second
        return l
    }

    fun config(dnsOverride: List<String>?): String = WgCheck.build(v.toMap(), dnsOverride)

    fun label(): String {
        val e = (v["ep"] ?: "").trim()
        if (e.isEmpty()) return "وایرگارد"
        val i = e.lastIndexOf(':')
        return if (i > 0) e.substring(0, i) else e
    }
}

object Wg {
    val up = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)

    @Volatile
    private var backend: GoBackend? = null

    private val tunnel = object : Tunnel {
        override fun getName(): String = "wg0"
        override fun onStateChange(newState: Tunnel.State) {
            up.value = newState == Tunnel.State.UP
        }
    }

    private fun be(ctx: Context): GoBackend {
        var b = backend
        if (b == null) {
            b = GoBackend(ctx.applicationContext)
            backend = b
        }
        return b
    }

    fun connect(ctx: Context, text: String) {
        Thread {
            try {
                val cfg = Config.parse(ByteArrayInputStream(text.toByteArray()))
                be(ctx).setState(tunnel, Tunnel.State.UP, cfg)
                error.value = null
                up.value = true
            } catch (e: Exception) {
                up.value = false
                error.value = "اتصال وایرگارد برقرار نشد: " + (e.message ?: "")
            }
        }.start()
    }

    fun disconnect(ctx: Context) {
        if (backend == null) {
            up.value = false
            return
        }
        Thread {
            try {
                be(ctx).setState(tunnel, Tunnel.State.DOWN, null)
            } catch (e: Exception) {
            }
            up.value = false
        }.start()
    }
}
