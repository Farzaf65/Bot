package com.dnschanger.app

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun Sw(checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Switch(
        checked = checked,
        onCheckedChange = onChange,
        enabled = enabled,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Accent,
            checkedTrackColor = Accent.copy(alpha = 0.25f),
            checkedBorderColor = Accent,
            uncheckedThumbColor = Muted,
            uncheckedTrackColor = Surface2,
            uncheckedBorderColor = Line
        )
    )
}

@Composable
fun SRow(title: String, desc: String, dim: Boolean = false, trailing: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 13.dp)
            .alpha(if (dim) 0.45f else 1f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Fg, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
            Text(desc, color = Muted, fontSize = 12.5.sp)
        }
        Spacer(Modifier.width(12.dp))
        trailing()
    }
}

@Composable
fun SwRow(title: String, desc: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    SRow(title, desc, dim = !enabled) { Sw(checked, enabled, onChange) }
}

@Composable
fun SoonRow(title: String, desc: String) {
    SRow(title, desc, dim = true) {
        Box(Modifier.border(1.dp, Violet.copy(alpha = 0.6f), CircleShape).padding(horizontal = 10.dp, vertical = 2.dp)) {
            Text("به‌زودی", color = Violet, fontSize = 11.5.sp)
        }
    }
}

@Composable
fun ActRow(title: String, desc: String, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    SRow(title, desc, dim = !enabled) {
        Box(
            Modifier
                .clip(CircleShape)
                .background(Surface2)
                .border(1.dp, Line, CircleShape)
                .clickable(enabled = enabled) { onClick() }
                .padding(horizontal = 16.dp, vertical = 7.dp)
        ) {
            Text(label, color = Fg, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
        }
    }
}

@Composable
fun Div() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
}

@Composable
fun GroupTitle(text: String) {
    Text(text, color = Accent, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 22.dp, bottom = 8.dp))
}

@Composable
fun Card(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(30.dp))
            .background(Surface2.copy(alpha = 0.55f))
            .border(1.dp, Line, RoundedCornerShape(30.dp)),
        content = content
    )
}

@Composable
fun SettingsScreen(store: Store, connected: Boolean, onMenu: () -> Unit, onExcl: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var pinDialog by remember { mutableStateOf(false) }
    var warn4 by remember { mutableStateOf(false) }
    val ver = tick

    fun set(k: String, v: Boolean) {
        store.setB(k, v)
        tick++
    }

    val notif = store.b("notif", true)
    val pinOn = store.b("pin", false) && store.pin.length == 4

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        TopBar(connected, false, onMenu)
        Spacer(Modifier.height(10.dp))
        Text("تنظیمات", color = Fg, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Text(
            "اعلان‌ها، قفل، استثنای برنامه‌ها و گزینه‌های عمومی. مواردی که «به‌زودی» دارن تو نسخه‌های بعد فعال می‌شن.",
            color = Muted, fontSize = 13.5.sp, modifier = Modifier.padding(top = 2.dp)
        )
        if (connected) {
            Text("تغییر تنظیمات از اتصال بعدی اعمال می‌شه.", color = Warn, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        }

        GroupTitle("اعلان‌ها")
        Card {
            SwRow("نمایش اعلان", "وقتی اپ فعاله یه اعلان نشون می‌ده. اگه اجازهٔ اعلان رو ندی نمایش داده نمی‌شه.", notif) { set("notif", it) }
            Div()
            SoonRow("مخفی کردن آیکون اعلان", "آیکون اپ تو نوار وضعیت دیده نمی‌شه.")
            Div()
            SwRow("نمایش DNSها تو اعلان", "آدرس DNSهای فعال تو اعلان نوشته می‌شه.", store.b("showDns", true), notif) { set("showDns", it) }
            Div()
            SoonRow("اعلان توقف", "اگه اپ خودش متوقف شد، دلیلش رو اعلان می‌کنه.")
        }

        GroupTitle("اتصال خودکار")
        Card {
            SoonRow("شروع بعد از روشن شدن گوشی", "اپ بعد از ریستارت خودش وصل می‌شه.")
            Div()
            SoonRow("شروع خودکار با وای‌فای", "وقتی به وای‌فای وصل شدی، اپ فعال می‌شه.")
            Div()
            SoonRow("شروع خودکار با دیتا", "وقتی روی دیتای موبایل هستی، اپ فعال می‌شه.")
            Div()
            SoonRow("قطع شدن با تغییر شبکه", "موقع عوض شدن شبکه اپ قطع می‌شه و دوباره فعال می‌شه.")
            Div()
            SoonRow("حالت دسترسی بالا", "اتوماسیون با دسترسی بیشتر اجرا می‌شه و پایدارتره.")
            Div()
            SwRow("فعال‌سازی بعد از آپدیت اپ", "اگه موقع آپدیت وصل بودی، بعد از آپدیت اپ خودش دوباره فعال می‌شه.", store.b("afterUpdate", true)) { set("afterUpdate", it) }
        }

        GroupTitle("قفل پین")
        Card {
            SwRow("پین", "ورود به اپ با پین ۴ رقمی.", pinOn) {
                if (it) {
                    if (store.pin.length == 4) set("pin", true) else pinDialog = true
                } else {
                    set("pin", false)
                }
            }
            Div()
            SwRow("محافظت از اپ", "موقع باز کردن اپ پین خواسته می‌شه.", store.b("pinApp", true), pinOn) { set("pinApp", it) }
            Div()
            SoonRow("محافظت از اعلان", "برای توقف یا مکث از اعلان، پین لازمه.")
            Div()
            SoonRow("محافظت از دکمه سریع", "برای وصل و قطع از Quick Settings پین لازمه.")
            Div()
            SoonRow("محافظت از میان‌بُرها", "برای وصل و قطع از میان‌بُر برنامه پین لازمه.")
            Div()
            SoonRow("فقط توقف عادی", "اپ فقط با روش‌های خودش متوقف می‌شه.")
            Div()
            ActRow("تغییر پین", "پین جدید ۴ رقمی انتخاب کن.", "تغییر", pinOn) { pinDialog = true }
        }

        GroupTitle("میان‌بُرها")
        Card {
            SoonRow("توقف با لمس دوباره میان‌بُر", "اگه دوباره روی میان‌بُری که اپ رو شروع کرده بزنی، اپ متوقف می‌شه.")
        }

        GroupTitle("استثنای برنامه‌ها")
        Card {
            ActRow(
                "برنامه‌های مستثنی",
                "این برنامه‌ها DNS اپ رو نمی‌گیرن (${store.excl.size} برنامه انتخاب شده).",
                "انتخاب"
            ) { onExcl() }
            Div()
            SwRow(
                "لیست سیاه",
                "روشن: برنامه‌های انتخاب‌شده DNS اپ رو نمی‌گیرن. خاموش: فقط همین برنامه‌ها DNS رو می‌گیرن.",
                store.b("blacklist", true)
            ) { set("blacklist", it) }
        }

        GroupTitle("عمومی")
        Card {
            SoonRow("مدیر دستگاه", "از حذف شدن اپ جلوگیری می‌کنه.")
            Div()
            SwRow("فعال‌سازی IPv4", "اجازه می‌ده آدرس IPv4 به‌عنوان DNS استفاده بشه.", store.b("ipv4", true)) {
                if (!it) warn4 = true else set("ipv4", true)
            }
            Div()
            SwRow("فعال‌سازی IPv6", "اجازه می‌ده آدرس IPv6 به‌عنوان DNS استفاده بشه.", store.b("ipv6", true)) { set("ipv6", it) }
            Div()
            SoonRow("میان‌بُر برنامه", "با لمس طولانی آیکون اپ، منوی وصل و قطع باز می‌شه.")
        }

        GroupTitle("عیب‌یابی")
        Card {
            SwRow("حالت دیباگ", "رویدادهای اپ (وصل و قطع و خطاها) تو یه فایل لاگ ذخیره می‌شه تا بتونی برای پشتیبانی بفرستی.", store.b("debug", false)) {
                set("debug", it)
                if (it) Logx.d("debug mode on")
            }
            Div()
            ActRow("ارسال لاگ", "لاگ ثبت‌شده رو با تلگرام یا هر برنامهٔ دیگه برای پشتیبانی بفرست.", "ارسال", store.b("debug", false)) {
                val t = Logx.readDebug()
                if (t.isBlank()) toast(ctx, "هنوز لاگی ثبت نشده") else shareText(ctx, Logx.header() + "\n\n" + t, true)
            }
            Div()
            SwRow("گزارش خطا", "اگه اپ به‌خاطر خطا بسته بشه، دفعهٔ بعد می‌تونی گزارشش رو برای پشتیبانی بفرستی. اطلاعات شخصی توش نیست.", store.b("crash", true)) { set("crash", it) }
        }

        GroupTitle("پیشرفته")
        Card {
            SoonRow("تنظیمات پیشرفته", "موارد زیر فقط وقتی این گزینه روشنه کار می‌کنن.")
            Div()
            SoonRow("اجازه آدرس loopback", "وارد کردن آدرس‌هایی مثل 127.0.0.1 تو همه فیلدها.")
            Div()
            SoonRow("پورت دلخواه", "وارد کردن پورت تو فیلدهای DNS.")
            Div()
            SoonRow("DNS روی TCP", "درخواست‌های DNS با TCP فرستاده می‌شن، نه UDP.")
            Div()
            SoonRow("زمان انتظار TCP", "بعد از این مدت، اپ تلاش برای رسیدن به سرور DNS رو متوقف می‌کنه.")
            Div()
            SoonRow("ثبت درخواست‌ها", "همه درخواست‌های DNS وقتی اپ فعاله ثبت می‌شن.")
            Div()
            SoonRow("وایرگارد (WireGuard)", "فعال‌سازی وایرگارد و منوی «وایرگارد / DNS» تو نسخه‌های بعد اضافه می‌شه.")
        }
        Spacer(Modifier.height(28.dp))
    }

    if (pinDialog) {
        var pv by remember { mutableStateOf("") }
        var perr by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { pinDialog = false },
            containerColor = Surface2,
            title = { Text("پین ۴ رقمی", color = Fg) },
            text = {
                Column {
                    OutlinedTextField(
                        value = pv,
                        onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) pv = it },
                        singleLine = true,
                        isError = perr != null,
                        placeholder = { Text("0000", color = Muted) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        shape = RoundedCornerShape(30.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Accent, unfocusedBorderColor = Line, errorBorderColor = Bad,
                            focusedTextColor = Fg, unfocusedTextColor = Fg, errorTextColor = Fg, cursorColor = Accent
                        )
                    )
                    if (perr != null) Text(perr ?: "", color = Bad, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (pv.length != 4) {
                        perr = "پین باید دقیقاً ۴ رقم باشه."
                    } else {
                        store.pin = pv
                        set("pin", true)
                        pinDialog = false
                        toast(ctx, "پین تنظیم شد")
                    }
                }) { Text("ذخیره", color = Accent, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { pinDialog = false }) { Text("لغو", color = Muted) } }
        )
    }

    if (warn4) {
        AlertDialog(
            onDismissRequest = { warn4 = false },
            containerColor = Surface2,
            title = { Text("هشدار", color = Fg) },
            text = {
                Text(
                    "بیشتر نسخه‌های اندروید وقتی اپ فعاله و هیچ آدرس IPv4 داده نشده، به اینترنت دسترسی ندارن. باید روی گوشی خودت امتحان کنی.",
                    color = Muted, fontSize = 14.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    set("ipv4", false)
                    warn4 = false
                }) { Text("تأیید", color = Accent, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { warn4 = false }) { Text("لغو", color = Muted) } }
        )
    }
}

data class AppRow(val pkg: String, val label: String)

fun loadApps(ctx: Context): List<AppRow> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN)
    i.addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { AppRow(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun ExclScreen(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var sel by remember { mutableStateOf(store.excl) }
    var q by remember { mutableStateOf("") }
    val apps by produceState(initialValue = emptyList<AppRow>()) {
        value = withContext(Dispatchers.Default) { loadApps(ctx) }
    }
    val shown = apps.filter { q.isBlank() || it.label.contains(q.trim(), ignoreCase = true) }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            Column {
                Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        Modifier
                            .clip(CircleShape)
                            .background(Surface2)
                            .border(1.dp, Line, CircleShape)
                            .clickable { onBack() }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) { Text("بازگشت", color = Fg, fontWeight = FontWeight.Bold, fontSize = 13.5.sp) }
                    Text("برنامه‌های مستثنی", color = Fg, fontSize = 20.sp, fontWeight = FontWeight.Black)
                }
                Text(
                    if (store.b("blacklist", true)) "برنامه‌های تیک‌دار DNS اپ رو نمی‌گیرن و از DNS خود گوشی استفاده می‌کنن."
                    else "فقط برنامه‌های تیک‌دار DNS اپ رو می‌گیرن.",
                    color = Muted, fontSize = 13.5.sp, modifier = Modifier.padding(top = 8.dp, bottom = 10.dp)
                )
                OutlinedTextField(
                    value = q,
                    onValueChange = { q = it },
                    singleLine = true,
                    placeholder = { Text("جستجوی برنامه", color = Muted) },
                    shape = RoundedCornerShape(36.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Accent, unfocusedBorderColor = Line,
                        focusedTextColor = Fg, unfocusedTextColor = Fg, cursorColor = Accent
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
            }
        }
        if (apps.isEmpty()) {
            item { Text("در حال خوندن لیست برنامه‌ها...", color = Muted, modifier = Modifier.padding(16.dp)) }
        }
        items(shown, key = { it.pkg }) { a ->
            val on = a.pkg in sel
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable {
                        sel = if (on) sel - a.pkg else sel + a.pkg
                        store.excl = sel
                    }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Checkbox(
                    checked = on,
                    onCheckedChange = null,
                    colors = CheckboxDefaults.colors(checkedColor = Accent, uncheckedColor = Muted, checkmarkColor = AccentInk)
                )
                Text(a.label, color = Fg, fontSize = 15.sp)
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun LockScreen(store: Store, onUnlock: () -> Unit) {
    var v by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    Column(
        Modifier.fillMaxSize().background(Bg).systemBarsPadding().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(64.dp).background(Surface2, CircleShape).border(1.dp, Accent.copy(alpha = 0.5f), CircleShape), contentAlignment = Alignment.Center) {
            Text("D", color = Accent, fontWeight = FontWeight.Black, fontSize = 26.sp)
        }
        Spacer(Modifier.height(16.dp))
        Text("DNS چنجر", color = Fg, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Text("پین ۴ رقمی رو وارد کن", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))
        OutlinedTextField(
            value = v,
            onValueChange = { n ->
                if (n.length <= 4 && n.all { it.isDigit() }) {
                    v = n
                    err = false
                    if (n.length == 4) {
                        if (n == store.pin) {
                            onUnlock()
                        } else {
                            err = true
                            v = ""
                        }
                    }
                }
            },
            singleLine = true,
            isError = err,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            textStyle = TextStyle(color = Fg, fontSize = 22.sp, textAlign = TextAlign.Center),
            shape = RoundedCornerShape(36.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent, unfocusedBorderColor = Line, errorBorderColor = Bad,
                focusedTextColor = Fg, unfocusedTextColor = Fg, errorTextColor = Fg, cursorColor = Accent
            ),
            modifier = Modifier.width(200.dp).shaking(err).focusRequester(focus)
        )
        if (err) Text("پین اشتباهه.", color = Bad, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
    }
}
