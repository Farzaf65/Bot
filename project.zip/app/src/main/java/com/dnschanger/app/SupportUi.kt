package com.dnschanger.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SupportCard() {
    val ctx = LocalContext.current
    val shape = RoundedCornerShape(32.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Accent.copy(alpha = 0.16f), Violet.copy(alpha = 0.14f), Surface2.copy(alpha = 0.9f))))
            .border(1.dp, Brush.linearGradient(listOf(Accent.copy(alpha = 0.55f), Violet.copy(alpha = 0.4f))), shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(48.dp).background(Brush.linearGradient(listOf(Accent, Violet)), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Send, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.weight(1f)) {
                Text("پشتیبانی و ارتباط", color = Fg, fontSize = 16.5.sp, fontWeight = FontWeight.Black)
                Text("هر سؤال یا مشکلی داشتی، همین‌جا پیدا‌مون کن.", color = Muted, fontSize = 12.5.sp)
            }
        }

        Box(
            Modifier
                .fillMaxWidth()
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Accent, Color(0xFF5EEAD4))))
                .clickable { openUrl(ctx, "https://t.me/PINGAMIRREZA") }
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.Send, contentDescription = null, tint = AccentInk, modifier = Modifier.size(18.dp))
                Text("پیام در تلگرام  ·  @PINGAMIRREZA", color = AccentInk, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
            }
        }

        ContactTile("ایمیل", "farzad.km15@gmail.com", "mailto:farzad.km15@gmail.com", Accent, 0)
        ContactTile("کانال تلگرام", "@last_circle_king", "https://t.me/last_circle_king", Violet, 1)
        ContactTile("اینستاگرام", "last_circle_king", "https://instagram.com/last_circle_king", Color(0xFFF472B6), 2)

        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Warn.copy(alpha = 0.10f))
                .border(1.dp, Warn.copy(alpha = 0.28f), RoundedCornerShape(22.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("📸", fontSize = 18.sp)
            Text("هر ایرادی داشتین یه اسکرین‌شات برای من بفرستید.", color = Fg, fontSize = 13.sp, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun ContactTile(label: String, value: String, url: String, tint: Color, icon: Int) {
    val ctx = LocalContext.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Surface.copy(alpha = 0.55f))
            .border(1.dp, Line, RoundedCornerShape(26.dp))
            .clickable { openUrl(ctx, url) }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            Modifier.size(40.dp).background(tint.copy(alpha = 0.16f), CircleShape).border(1.dp, tint.copy(alpha = 0.45f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            when (icon) {
                0 -> Icon(Icons.Filled.Email, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
                1 -> Icon(Icons.Filled.Notifications, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
                else -> Canvas(Modifier.size(20.dp)) {
                    val w = size.width
                    val st = Stroke(1.8.dp.toPx())
                    drawRoundRect(tint, Offset(w * 0.08f, w * 0.08f), Size(w * 0.84f, w * 0.84f), CornerRadius(w * 0.26f), style = st)
                    drawCircle(tint, radius = w * 0.2f, center = center, style = st)
                    drawCircle(tint, radius = w * 0.055f, center = Offset(w * 0.73f, w * 0.27f))
                }
            }
        }
        Column(Modifier.weight(1f)) {
            Text(label, color = Muted, fontSize = 11.5.sp)
            Text(
                value,
                color = Fg,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = TextStyle(textDirection = TextDirection.Ltr)
            )
        }
        Box(
            Modifier
                .clip(CircleShape)
                .background(Surface2)
                .border(1.dp, Line, CircleShape)
                .clickable { copyText(ctx, value) }
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text("کپی", color = Fg, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
        }
    }
}
