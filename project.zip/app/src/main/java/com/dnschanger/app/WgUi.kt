package com.dnschanger.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val WG_BASIC = listOf("priv", "addr", "pub", "psk", "ep")

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WgPane(
    form: WgForm,
    locked: Boolean,
    bring: Map<String, BringIntoViewRequester>,
    focus: Map<String, FocusRequester>
) {
    val ctx = LocalContext.current
    var showKeys by remember { mutableStateOf(false) }
    var pasteDialog by remember { mutableStateOf(false) }

    fun apply(text: String) {
        val m = WgCheck.parse(text)
        if (m.isEmpty()) {
            toast(ctx, "هیچ فیلد وایرگارد تو متن پیدا نشد.")
            return
        }
        form.fill(m)
        form.err.clear()
        toast(
            ctx,
            if (WgCheck.hasAmnezia(text)) "${m.size} مورد وارد شد. پارامترهای AmneziaWG نادیده گرفته شدن."
            else "${m.size} مورد وارد شد"
        )
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val t = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                apply(t)
            } catch (e: Exception) {
                toast(ctx, "فایل خونده نشد.")
            }
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Text("کانفیگ وایرگارد", color = Fg, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
        Text(
            "متن یا فایل کانفیگ (.conf) رو وارد کن، یا فیلدها رو دستی پر کن. کلیدها رمزنگاری‌شده تو گوشی ذخیره می‌شن و هیچ‌جا ارسال نمی‌شن.",
            color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Chip("paste کردن متن", Accent) { if (locked) toast(ctx, "اول اتصال رو قطع کن") else pasteDialog = true }
            Chip("انتخاب فایل", Accent) { if (locked) toast(ctx, "اول اتصال رو قطع کن") else picker.launch(arrayOf("*/*")) }
            TextButton(onClick = { if (locked) toast(ctx, "اول اتصال رو قطع کن") else form.clear() }) {
                Text("پاک کردن", color = Accent, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(10.dp))

        Text("[Interface]  دستگاه تو", color = Violet, fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(vertical = 8.dp))
        for (f in WGF.filter { !it.peer && it.k in WG_BASIC }) WgFieldView(f, form, locked, bring, focus, showKeys) { showKeys = !showKeys }
        Text("[Peer]  سرور", color = Violet, fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(vertical = 8.dp))
        for (f in WGF.filter { it.peer && it.k in WG_BASIC }) WgFieldView(f, form, locked, bring, focus, showKeys) { showKeys = !showKeys }
        Text(
            "MTU، Keepalive، مسیرها و DNS تونل بعد از وارد کردن کانفیگ، تو تنظیمات ← پیشرفته باز می‌شن.",
            color = Muted, fontSize = 12.5.sp, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
        )
    }

    if (pasteDialog) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pasteDialog = false },
            containerColor = Surface2,
            title = { Text("paste کردن کانفیگ", color = Fg) },
            text = {
                Column {
                    Text("متن کامل فایل .conf رو paste کن. فقط اولین Peer خونده می‌شه.", color = Muted, fontSize = 13.5.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        minLines = 6,
                        maxLines = 10,
                        placeholder = { Text("[Interface]\nPrivateKey = ...\nAddress = 10.8.0.2/32\n\n[Peer]\nPublicKey = ...\nEndpoint = vpn.example.com:51820", color = Muted, fontSize = 12.sp) },
                        textStyle = TextStyle(color = Fg, fontFamily = FontFamily.Monospace, fontSize = 12.5.sp, textDirection = TextDirection.Ltr, textAlign = TextAlign.Left),
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Accent, unfocusedBorderColor = Line,
                            focusedTextColor = Fg, unfocusedTextColor = Fg, cursorColor = Accent
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    apply(text)
                    pasteDialog = false
                }) { Text("وارد کن", color = Accent, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { pasteDialog = false }) { Text("لغو", color = Muted) } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WgFieldView(
    f: WgField,
    form: WgForm,
    locked: Boolean,
    bring: Map<String, BringIntoViewRequester>,
    focus: Map<String, FocusRequester>,
    showKeys: Boolean,
    onToggleShow: () -> Unit
) {
    var mod: Modifier = Modifier
    val br = bring[f.k]
    val fr = focus[f.k]
    if (br != null) mod = mod.bringIntoViewRequester(br)
    if (fr != null) mod = mod.focusRequester(fr)
    val tr: (@Composable () -> Unit)? = if (f.secret) ({
        TextButton(onClick = onToggleShow) {
            Text(if (showKeys) "پنهان" else "نمایش", color = Accent, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
        }
    }) else null
    Column(Modifier.padding(bottom = 10.dp)) {
        DnsField(
            title = f.name + "  ·  " + f.fa,
            tag = if (f.req) "اجباری" else "اختیاری",
            value = form.v[f.k] ?: "",
            onValue = { form.set(f.k, it) },
            placeholder = f.ph,
            error = form.err[f.k],
            warn = null,
            enabled = !locked,
            fieldModifier = mod,
            visual = if (f.secret && !showKeys) PasswordVisualTransformation() else VisualTransformation.None,
            trailing = tr
        )
    }
}

@Composable
fun Chip(text: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(CircleShape)
            .border(1.dp, color.copy(alpha = 0.5f), CircleShape)
            .background(color.copy(alpha = 0.06f))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(text, color = color, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
    }
}

@Composable
fun Dock(tab: String, onTab: (String) -> Unit, modifier: Modifier = Modifier) {
    BoxWithConstraints(
        modifier
            .widthIn(max = 340.dp)
            .fillMaxWidth()
            .height(60.dp)
            .clip(CircleShape)
            .background(Surface.copy(alpha = 0.94f))
            .border(1.dp, Line, CircleShape)
            .padding(5.dp)
    ) {
        val half = maxWidth / 2
        val x by animateDpAsState(
            if (tab == "wg") 0.dp else half,
            spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow),
            label = "dock"
        )
        Box(
            Modifier
                .offset(x = x)
                .width(half)
                .fillMaxHeight()
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Accent.copy(alpha = 0.22f), Violet.copy(alpha = 0.22f))))
                .border(1.dp, Accent.copy(alpha = 0.45f), CircleShape)
        )
        Row(Modifier.fillMaxSize()) {
            DockItem("وایرگارد", tab == "wg", true, Modifier.weight(1f)) { onTab("wg") }
            DockItem("DNS", tab == "dns", false, Modifier.weight(1f)) { onTab("dns") }
        }
    }
}

@Composable
fun DockItem(label: String, active: Boolean, shield: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val tint = if (active) Accent else Muted
    Box(
        modifier.fillMaxHeight().clip(CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Canvas(Modifier.size(20.dp)) {
                val w = size.width
                val st = Stroke(1.8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                if (shield) {
                    val p = Path()
                    p.moveTo(w * 0.5f, w * 0.04f)
                    p.lineTo(w * 0.9f, w * 0.2f)
                    p.lineTo(w * 0.9f, w * 0.52f)
                    p.lineTo(w * 0.5f, w * 0.96f)
                    p.lineTo(w * 0.1f, w * 0.52f)
                    p.lineTo(w * 0.1f, w * 0.2f)
                    p.close()
                    drawPath(p, tint, style = st)
                } else {
                    drawCircle(tint, radius = w * 0.14f, center = center, style = st)
                    drawCircle(tint, radius = w * 0.38f, center = center, style = st)
                }
            }
            Text(label, color = tint, fontWeight = FontWeight.Bold)
        }
    }
}
