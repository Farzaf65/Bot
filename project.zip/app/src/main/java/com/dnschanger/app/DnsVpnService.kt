package com.dnschanger.app

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Sets up a local VPN interface that only carries DNS traffic.
 * The system is told that its DNS server is a fake address inside the tunnel.
 * Every DNS query that arrives there is forwarded (through a protected socket,
 * so it bypasses the tunnel) to the DNS servers the user typed, in order,
 * and the answer is written back. All other traffic is not touched.
 */
class DnsVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.dnschanger.app.START"
        const val ACTION_STOP = "com.dnschanger.app.STOP"
        const val EXTRA_DNS = "dns"
        private const val FAKE_DNS = "10.111.222.2"
        private val FAKE_BYTES = intArrayOf(10, 111, 222, 2)

        val connected = MutableStateFlow(false)
        val lastError = MutableStateFlow<String?>(null)
    }

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private var pool: ExecutorService? = null

    @Volatile
    private var upstream: List<String> = emptyList()

    @Volatile
    private var running = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAll()
            stopSelf()
            return START_NOT_STICKY
        }
        val list = intent?.getStringArrayListExtra(EXTRA_DNS) ?: arrayListOf()
        if (list.isEmpty()) {
            stopAll()
            stopSelf()
            return START_NOT_STICKY
        }
        startAll(list)
        return START_NOT_STICKY
    }

    private fun startAll(list: List<String>) {
        stopAll()
        upstream = list
        val fd: ParcelFileDescriptor? = try {
            Builder()
                .setSession("DNS چنجر")
                .addAddress("10.111.222.1", 24)
                .addDnsServer(FAKE_DNS)
                .addRoute(FAKE_DNS, 32)
                .setMtu(1500)
                .establish()
        } catch (e: Exception) {
            null
        }
        if (fd == null) {
            lastError.value = "اتصال برقرار نشد. مجوز VPN رو بررسی کن."
            connected.value = false
            stopSelf()
            return
        }
        tun = fd
        running = true
        pool = Executors.newFixedThreadPool(4)
        val t = Thread { loop(fd) }
        worker = t
        t.start()
        lastError.value = null
        connected.value = true
    }

    private fun stopAll() {
        running = false
        connected.value = false
        try {
            tun?.close()
        } catch (e: Exception) {
        }
        tun = null
        pool?.shutdownNow()
        pool = null
        worker?.interrupt()
        worker = null
    }

    override fun onRevoke() {
        stopAll()
        stopSelf()
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    private fun loop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (running) {
                val n = input.read(buf)
                if (n < 0) break
                if (n < 28) continue
                handle(buf, n, output)
            }
        } catch (e: Exception) {
        } finally {
            if (running) {
                stopAll()
                stopSelf()
            }
        }
    }

    private fun u8(b: Byte): Int = b.toInt() and 0xFF

    private fun handle(buf: ByteArray, n: Int, output: FileOutputStream) {
        if ((u8(buf[0]) shr 4) != 4) return
        val ihl = (u8(buf[0]) and 0x0F) * 4
        if (u8(buf[9]) != 17) return
        if (ihl + 8 > n) return
        for (i in 0..3) {
            if (u8(buf[16 + i]) != FAKE_BYTES[i]) return
        }
        val sport = (u8(buf[ihl]) shl 8) or u8(buf[ihl + 1])
        val dport = (u8(buf[ihl + 2]) shl 8) or u8(buf[ihl + 3])
        if (dport != 53) return
        val total = (u8(buf[2]) shl 8) or u8(buf[3])
        val end = if (total in (ihl + 8)..n) total else n
        val payload = buf.copyOfRange(ihl + 8, end)
        val clientIp = buf.copyOfRange(12, 16)
        val ex = pool ?: return
        try {
            ex.execute {
                val answer = forward(payload) ?: return@execute
                val packet = buildReply(clientIp, sport, answer) ?: return@execute
                try {
                    synchronized(output) { output.write(packet) }
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun forward(query: ByteArray): ByteArray? {
        for (server in upstream) {
            try {
                val sock = DatagramSocket()
                try {
                    protect(sock)
                    sock.soTimeout = 2500
                    val addr = InetAddress.getByName(server)
                    sock.send(DatagramPacket(query, query.size, addr, 53))
                    val rb = ByteArray(4096)
                    val rp = DatagramPacket(rb, rb.size)
                    sock.receive(rp)
                    return rb.copyOf(rp.length)
                } finally {
                    sock.close()
                }
            } catch (e: Exception) {
                // try the next server
            }
        }
        return null
    }

    private fun buildReply(clientIp: ByteArray, clientPort: Int, answer: ByteArray): ByteArray? {
        val total = 28 + answer.size
        if (total > 1500) return null
        val out = ByteArray(total)
        out[0] = 0x45
        out[2] = (total shr 8).toByte()
        out[3] = (total and 0xFF).toByte()
        out[6] = 0x40
        out[8] = 64
        out[9] = 17
        for (i in 0..3) {
            out[12 + i] = FAKE_BYTES[i].toByte()
            out[16 + i] = clientIp[i]
        }
        var sum = 0
        var i = 0
        while (i < 20) {
            sum += (u8(out[i]) shl 8) or u8(out[i + 1])
            i += 2
        }
        while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val ck = sum.inv() and 0xFFFF
        out[10] = (ck shr 8).toByte()
        out[11] = (ck and 0xFF).toByte()
        out[20] = 0
        out[21] = 53
        out[22] = (clientPort shr 8).toByte()
        out[23] = (clientPort and 0xFF).toByte()
        val ulen = 8 + answer.size
        out[24] = (ulen shr 8).toByte()
        out[25] = (ulen and 0xFF).toByte()
        System.arraycopy(answer, 0, out, 28, answer.size)
        return out
    }
}
