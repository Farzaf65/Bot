package com.dnschanger.app

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.sin

val Bg = Color(0xFF070B12)
val Surface = Color(0xFF0D1420)
val Surface2 = Color(0xFF131D2E)
val Line = Color(0xFF1F2E46)
val Fg = Color(0xFFEAF1FB)
val Muted = Color(0xFF8193AC)
val Accent = Color(0xFF22D3EE)
val AccentInk = Color(0xFF021C22)
val Violet = Color(0xFF7C5CFF)
val Good = Color(0xFF4ADE80)
val Warn = Color(0xFFFBBF24)
val Bad = Color(0xFFF87171)

fun toast(ctx: Context, text: String) {
    Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show()
}

/** Keeps shaking in short bursts while [on] is true. */
@Composable
fun Modifier.shaking(on: Boolean): Modifier {
    val t = rememberInfiniteTransition(label = "shake")
    val x by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing)),
        label = "shakeX"
    )
    if (!on) return this
    return this.graphicsLayer {
        translationX = if (x < 0.3f) (sin((x / 0.3f) * PI * 6) * 8.0 * density).toFloat() else 0f
    }
}

@Composable
fun PowerButton(connected: Boolean, connecting: Boolean, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "power")
    val spin by inf.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing)),
        label = "spin"
    )
    val slow by inf.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "slow"
    )
    val breathe by inf.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.45f,
        animationSpec = infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe"
    )
    val progress by animateFloatAsState(if (connected) 1f else 0f, tween(700), label = "progress")
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        if (pressed) 0.95f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press"
    )

    Box(
        modifier = Modifier
            .size(244.dp)
            .scale(pressScale)
            .clip(CircleShape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f
            val disc = 102.dp.toPx()

            if (!connected && !connecting) {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Accent.copy(alpha = breathe * 0.5f), Color.Transparent),
                        center = c,
                        radius = r
                    ),
                    radius = r,
                    center = c
                )
            }
            drawCircle(
                color = Line.copy(alpha = 0.7f),
                radius = r - 2.dp.toPx(),
                center = c,
                style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 12f)))
            )
            if (connected || connecting) {
                rotate(slow, c) {
                    drawCircle(
                        brush = Brush.sweepGradient(
                            listOf(Accent, Violet, Accent.copy(alpha = 0.1f), Accent),
                            center = c
                        ),
                        radius = r - 8.dp.toPx(),
                        center = c,
                        style = Stroke(7.dp.toPx()),
                        alpha = if (connected) 0.75f else 0.35f
                    )
                }
            }
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFF1A2840), Surface),
                    center = Offset(c.x, c.y - disc * 0.4f),
                    radius = disc * 1.6f
                ),
                radius = disc,
                center = c
            )
            drawCircle(Line, radius = disc, center = c, style = Stroke(1.dp.toPx()))

            val rr = disc - 2.dp.toPx()
            drawCircle(Line, radius = rr, center = c, style = Stroke(6.dp.toPx()))
            val startRot = if (connecting && !connected) spin - 90f else -90f
            val sweep = if (connecting && !connected) 120f else 360f * progress
            if (sweep > 0f) {
                rotate(startRot, c) {
                    drawArc(
                        brush = Brush.sweepGradient(listOf(Accent, Violet, Accent), center = c),
                        startAngle = 0f,
                        sweepAngle = sweep,
                        useCenter = false,
                        topLeft = Offset(c.x - rr, c.y - rr),
                        size = Size(rr * 2, rr * 2),
                        style = Stroke(6.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            val ic = if (connected) Accent else Muted
            val ir = 26.dp.toPx()
            drawArc(
                color = ic,
                startAngle = -60f,
                sweepAngle = 300f,
                useCenter = false,
                topLeft = Offset(c.x - ir, c.y - ir),
                size = Size(ir * 2, ir * 2),
                style = Stroke(5.dp.toPx(), cap = StrokeCap.Round)
            )
            drawLine(
                color = ic,
                start = Offset(c.x, c.y - ir * 1.15f),
                end = Offset(c.x, c.y - ir * 0.1f),
                strokeWidth = 5.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun PathRow(step: Int, dnsLabel: String, connected: Boolean) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        PathNode("اپلیکیشن DNS", step >= 1, 0)
        Wire(step >= 2, connected, 0f, Modifier.weight(1f).padding(top = 22.dp))
        PathNode(dnsLabel, step >= 2, 1)
        Wire(step >= 3, connected, 0.5f, Modifier.weight(1f).padding(top = 22.dp))
        PathNode("اینترنت", step >= 3, 2)
    }
}

@Composable
fun PathNode(label: String, lit: Boolean, kind: Int) {
    val border by animateColorAsState(if (lit) Accent.copy(alpha = 0.7f) else Line, tween(400), label = "nb")
    val tint by animateColorAsState(if (lit) Accent else Muted, tween(400), label = "nt")
    val sc by animateFloatAsState(
        if (lit) 1.07f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "ns"
    )
    Column(Modifier.width(88.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(54.dp)
                .scale(sc)
                .background(Surface2, CircleShape)
                .border(1.dp, border, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(26.dp)) {
                val w = size.width
                val st = Stroke(1.8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                when (kind) {
                    0 -> {
                        val p = Path()
                        p.moveTo(w * 0.04f, w * 0.52f)
                        p.lineTo(w * 0.28f, w * 0.52f)
                        p.lineTo(w * 0.40f, w * 0.20f)
                        p.lineTo(w * 0.58f, w * 0.80f)
                        p.lineTo(w * 0.70f, w * 0.38f)
                        p.lineTo(w * 0.76f, w * 0.52f)
                        p.lineTo(w * 0.96f, w * 0.52f)
                        drawPath(p, tint, style = st)
                    }
                    1 -> {
                        drawCircle(tint, radius = w * 0.14f, center = center, style = st)
                        drawCircle(tint, radius = w * 0.36f, center = center, style = st)
                        drawLine(tint, Offset(w * 0.5f, 0f), Offset(w * 0.5f, w * 0.1f), 1.8.dp.toPx(), StrokeCap.Round)
                        drawLine(tint, Offset(w * 0.5f, w * 0.9f), Offset(w * 0.5f, w), 1.8.dp.toPx(), StrokeCap.Round)
                        drawLine(tint, Offset(0f, w * 0.5f), Offset(w * 0.1f, w * 0.5f), 1.8.dp.toPx(), StrokeCap.Round)
                        drawLine(tint, Offset(w * 0.9f, w * 0.5f), Offset(w, w * 0.5f), 1.8.dp.toPx(), StrokeCap.Round)
                    }
                    else -> {
                        drawCircle(tint, radius = w * 0.42f, center = center, style = st)
                        drawLine(tint, Offset(w * 0.08f, w * 0.5f), Offset(w * 0.92f, w * 0.5f), 1.8.dp.toPx(), StrokeCap.Round)
                        drawOval(
                            tint,
                            topLeft = Offset(w * 0.3f, w * 0.08f),
                            size = Size(w * 0.4f, w * 0.84f),
                            style = st
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            color = if (lit) Fg else Muted,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun Wire(lit: Boolean, connected: Boolean, phase: Float, modifier: Modifier) {
    val progress by animateFloatAsState(if (lit) 1f else 0f, tween(550), label = "wire")
    val inf = rememberInfiniteTransition(label = "dot")
    val t by inf.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing)),
        label = "dotT"
    )
    Canvas(modifier.height(8.dp)) {
        val y = size.height / 2f
        val rtl = layoutDirection == LayoutDirection.Rtl
        val w = size.width
        fun xAt(f: Float): Float = if (rtl) w * (1f - f) else w * f
        val dash = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 6.dp.toPx()), 0f)
        drawLine(Line, Offset(0f, y), Offset(w, y), 2.dp.toPx(), pathEffect = dash)
        if (progress > 0.001f) {
            drawLine(Accent, Offset(xAt(0f), y), Offset(xAt(progress), y), 2.dp.toPx(), pathEffect = dash)
            if (connected) {
                val f = (t + phase) % 1f
                drawCircle(Color.White, 3.5.dp.toPx(), Offset(xAt(f), y))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DnsField(
    title: String,
    tag: String,
    value: String,
    onValue: (String) -> Unit,
    placeholder: String,
    error: String?,
    warn: String?,
    enabled: Boolean,
    fieldModifier: Modifier = Modifier
) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(title, color = Fg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Box(Modifier.border(1.dp, Line, CircleShape).padding(horizontal = 8.dp, vertical = 1.dp)) {
                Text(tag, color = Muted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(4.dp))
        val mono = TextStyle(
            color = Fg,
            fontFamily = FontFamily.Monospace,
            fontSize = 16.sp,
            textDirection = TextDirection.Ltr,
            textAlign = TextAlign.Left
        )
        OutlinedTextField(
            value = value,
            onValueChange = onValue,
            enabled = enabled,
            singleLine = true,
            isError = error != null,
            placeholder = { Text(placeholder, color = Color(0xFF3B4B66), style = mono.copy(color = Color(0xFF3B4B66))) },
            textStyle = mono,
            shape = RoundedCornerShape(36.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent,
                unfocusedBorderColor = Line,
                errorBorderColor = Bad,
                disabledBorderColor = Line.copy(alpha = 0.5f),
                focusedContainerColor = Surface.copy(alpha = 0.7f),
                unfocusedContainerColor = Surface.copy(alpha = 0.7f),
                errorContainerColor = Bad.copy(alpha = 0.08f),
                disabledContainerColor = Surface.copy(alpha = 0.4f),
                cursorColor = Accent,
                focusedTextColor = Fg,
                unfocusedTextColor = Fg,
                errorTextColor = Fg,
                disabledTextColor = Muted
            ),
            modifier = Modifier.fillMaxWidth().shaking(error != null).then(fieldModifier)
        )
        if (error != null) {
            Text(error, color = Bad, fontSize = 13.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp))
        } else if (warn != null) {
            Text(warn, color = Warn, fontSize = 13.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp))
        }
    }
}
